<?php
/**
 * ACF Content Analysis for Yoast SEO test file.
 *
 * @package YoastACFAnalysis
 */

/**
 * Test helper.
 */
class acf {

}
