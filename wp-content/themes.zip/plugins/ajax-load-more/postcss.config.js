module.exports = {
  plugins: {
    'autoprefixer': {browsers: ['last 10 versions']},
  }
}
